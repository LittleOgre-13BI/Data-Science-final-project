import re
import os
import textDeconstruct

def DFcou():
    DF = {}
    path = './分词对照集/'
    os.getcwd()
    List = os.listdir(path)
    for item in List:
        childPath = path+item+'/'
        fileList = os.listdir(childPath)
        for file in fileList:
            if item == '人民日报训练集':
                fw = open(childPath + file, 'rb')
                text = fw.read()
                try:
                    text = text.decode('utf8')
                except Exception:
                    text = text.decode('utf8', 'ignore')
                fw.close()
                words = re.split('[|]',text)
                wordList = []
                for word in words:
                    if word not in wordList:
                        wordList.append(word)

                for word in wordList:
                    if word in DF:
                        DF[word] += 1
                    else:
                        DF[word] = 1
            else:
                newText = textDeconstruct.deconstruct(childPath+file)
                words = re.split('[|]', newText['text'])
                wordList = []
                for word in words:
                    if word not in wordList:
                        wordList.append(word)

                for word in wordList:
                    if word in DF:
                        DF[word] += 1
                    else:
                        DF[word] = 1

    wordslist = sorted(DF.items(), key=lambda item:item[1], reverse=True)
    return wordslist

if __name__ == '__main__':
    wordslist = DFcou()
    for word in wordslist:
        print('{0}:{1}'.format(word[0],word[1]))